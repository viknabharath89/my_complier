function signup() {
    let username = document.getElementById("signupUser").value.trim();
    let email = document.getElementById("signupEmail").value.trim();
    let password = document.getElementById("signupPass").value;
    let confirm = document.getElementById("confirmPass").value;
    let terms = document.getElementById("terms").checked;

    let valid = true;

    // Clear errors
    document.querySelectorAll("small").forEach(e => e.innerText = "");

    // USERNAME
    if (username.length < 4) {
        showError("userError", "Min 4 characters required");
        valid = false;
    }

    // EMAIL
    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!email.match(emailPattern)) {
        showError("emailError", "Invalid email format");
        valid = false;
    }

    // PASSWORD
    let passPattern = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&]).{6,}$/;
    if (!password.match(passPattern)) {
        showError("passError", "6+ chars, 1 uppercase, 1 number, 1 special char");
        valid = false;
    }

    // CONFIRM
    if (password !== confirm) {
        showError("confirmError", "Passwords do not match");
        valid = false;
    }

    // TERMS
    if (!terms) {
        alert("You must agree to terms");
        valid = false;
    }

    if (!valid) return;

    // Save data
    localStorage.setItem("username", username);
    localStorage.setItem("email", email);
    localStorage.setItem("password", password);

    alert("Account created successfully!");
    window.location.href = "login.html";
}

// Show error
function showError(id, msg) {
    document.getElementById(id).innerText = msg;
}

// Toggle password
function togglePassword(el) {
    let field = document.getElementById("loginPass");
    let icon = el.querySelector("i");

    if (field.type === "password") {
        field.type = "text";
        icon.classList.replace("fa-eye", "fa-eye-slash");
    } else {
        field.type = "password";
        icon.classList.replace("fa-eye-slash", "fa-eye");
    }
}