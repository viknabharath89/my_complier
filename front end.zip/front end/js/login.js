function login() {
    let user = document.getElementById("loginUser").value.trim();
    let pass = document.getElementById("loginPass").value;

    let storedUser = localStorage.getItem("username");
    let storedEmail = localStorage.getItem("email");
    let storedPass = localStorage.getItem("password");

    let valid = true;

    document.getElementById("loginUserError").innerText = "";
    document.getElementById("loginPassError").innerText = "";

    if (user === "") {
        showError("loginUserError", "Enter username or email");
        valid = false;
    }

    if (pass === "") {
        showError("loginPassError", "Enter password");
        valid = false;
    }

    if (!valid) return;

    if ((user === storedUser || user === storedEmail) && pass === storedPass) {
        alert("Login successful!");
        window.location.href = "dashboard.html";
    } else {
        showError("loginPassError", "Invalid credentials");
    }
}

/* Show error */
function showError(id, msg) {
    document.getElementById(id).innerText = msg;
}

/* Toggle password */
function togglePassword(el) {
    let field = document.getElementById("loginPass");
    let icon = el.querySelector("i");

    if (field.type === "password") {
        field.type = "text";
        icon.classList.replace("fa-eye", "fa-eye-slash");
    } else {
        field.type = "password";
        icon.classList.replace("fa-eye-slash", "fa-eye");
    }
}